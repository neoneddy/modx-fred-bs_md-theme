<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'fred' => '*',
      'Fred Font Awesome 5 Icon Editor' => '*',
      'Fred TinyMCE RTE' => '*',
      'pdoTools' => '*',
      'pThumb' => '*',
      'resizer' => '*',
    ),
    'changelog' => 'First Build',
    'readme' => 'words',
    'license' => 'words',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '2e1329627ee3bd611dd85b2074985a0a',
      'native_key' => '2e1329627ee3bd611dd85b2074985a0a',
      'filename' => 'xPDOScriptVehicle/65f5778638756043b1198b591b67c58b.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '369d26fd8c80a3b75e4bc066e254ec31',
      'native_key' => '369d26fd8c80a3b75e4bc066e254ec31',
      'filename' => 'xPDOFileVehicle/0fdbf68a531e376f22ff6f6af7119dcc.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4c278914cd3a07e04df1e98458c754b0',
      'native_key' => '4c278914cd3a07e04df1e98458c754b0',
      'filename' => 'xPDOScriptVehicle/b2aa4f5bcfdd9996165120cb6ecf5d28.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'FredTheme',
      'guid' => 'dfb3664b7b46efd4a136cf471090affd',
      'native_key' => 1,
      'filename' => 'FredTheme/e08d65003e26972833655256824b4c8e.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '82fcedc0136d9496ca96d89bb074e39a',
      'native_key' => '82fcedc0136d9496ca96d89bb074e39a',
      'filename' => 'xPDOScriptVehicle/6846adad2ba17f521a0170c2429987f4.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4a25c8ade47b48c9a4cb33f01f5e7038',
      'native_key' => '4a25c8ade47b48c9a4cb33f01f5e7038',
      'filename' => 'xPDOScriptVehicle/3e308fc81558a87ced0cb5a32e4f68f7.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ec45e00633d52ba6f4d4c3da7de80293',
      'native_key' => 'ec45e00633d52ba6f4d4c3da7de80293',
      'filename' => 'xPDOScriptVehicle/613eb50ce3c576de09971956d9849b65.vehicle',
    ),
  ),
);